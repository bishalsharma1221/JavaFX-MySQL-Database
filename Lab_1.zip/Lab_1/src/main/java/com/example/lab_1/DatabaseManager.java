package com.example.lab_1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;

import java.sql.*;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3307/student_db";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    // Database Connection
    public static Connection connect() {
        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Successfully connected to the database!");
            return conn;
        } catch (SQLException e) {
            System.out.println("❌ Connection failed: " + e.getMessage());
            return null;
        }
    }

    // Load students into TableView
    public static void loadStudents(TableView<Student> table) {
        ObservableList<Student> students = FXCollections.observableArrayList();
        String query = "SELECT * FROM students";

        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (conn == null) {
                System.out.println("❌ Database connection failed!");
                return;
            }

            System.out.println("✅ Fetching data...");

            while (rs.next()) {
                students.add(new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("grade")
                ));
            }

            table.setItems(students);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Add student to the database
    public static void addStudent(int id, String name, int age, String grade) {
        String insertQuery = "INSERT INTO students (id, name, age, grade) VALUES (?, ?, ?, ?)";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setInt(3, age);
            pstmt.setString(4, grade);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("✅ Student added successfully!");
            }
        } catch (SQLException e) {
            System.out.println("❌ Error inserting student: " + e.getMessage());
        }
    }
}
