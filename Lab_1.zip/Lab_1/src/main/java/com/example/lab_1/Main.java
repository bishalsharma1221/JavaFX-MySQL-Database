package com.example.lab_1;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
    private TableView<Student> table;
    private TextField idField, nameField, ageField, gradeField;

    @Override
    public void start(Stage primaryStage) {
        // Table setup
        table = new TableView<>();
        TableColumn<Student, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());

        TableColumn<Student, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

        TableColumn<Student, Integer> ageColumn = new TableColumn<>("Age");
        ageColumn.setCellValueFactory(cellData -> cellData.getValue().ageProperty().asObject());

        TableColumn<Student, String> gradeColumn = new TableColumn<>("Grade");
        gradeColumn.setCellValueFactory(cellData -> cellData.getValue().gradeProperty());

        table.getColumns().addAll(idColumn, nameColumn, ageColumn, gradeColumn);

        // Input fields
        idField = new TextField();
        idField.setPromptText("ID");

        nameField = new TextField();
        nameField.setPromptText("Name");

        ageField = new TextField();
        ageField.setPromptText("Age");

        gradeField = new TextField();
        gradeField.setPromptText("Grade");

        // Buttons
        Button loadDataButton = new Button("Load Data");
        loadDataButton.setOnAction(e -> DatabaseManager.loadStudents(table));

        Button addButton = new Button("Add Student");
        addButton.setOnAction(e -> addStudent());

        // Layout
        VBox layout = new VBox(10, table, idField, nameField, ageField, gradeField, addButton, loadDataButton);
        layout.setPadding(new Insets(20));

        // Scene setup
        Scene scene = new Scene(layout, 600, 500);
        primaryStage.setTitle("Student Database - Your Name, ID: XXXXX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addStudent() {
        try {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            String grade = gradeField.getText();

            DatabaseManager.addStudent(id, name, age, grade);
            DatabaseManager.loadStudents(table); // Refresh table after adding
            clearFields();
        } catch (NumberFormatException e) {
            System.out.println("⚠ Please enter valid data!");
        }
    }

    private void clearFields() {
        idField.clear();
        nameField.clear();
        ageField.clear();
        gradeField.clear();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


