module com.example.lab_1 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.management;
    requires java.sql;

    opens com.example.lab_1 to javafx.fxml;
    exports com.example.lab_1;
}